.. _pyramid_handlers_api:

:mod:`pyramid_handlers` API
---------------------------

.. automodule:: pyramid_handlers

.. autofunction:: add_handler

.. autoclass:: action

